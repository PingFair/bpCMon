package example;

import com.bprbm.ecl.ECLAction;

/**
 * 
 * @decription this class is an example of using bpCMon to analysis XES Log file to check whether the log is 
 *             compliant or not. 
 * @author Fair
 * @date  2017/3/24 3:57:43
 * @note
 */

public class XESAnalysis {

	public static void main(String[] args) {
		
		// At first, create an ECLAction object, which is completely responsible for parsing ECL language, generating monitor, 
		// , executing monitor, and getting compliance results, etc. 
		ECLAction action = new ECLAction() ;
		
		// specify the ECL file to be parsed. Note that, in the running, 
		// this eclfile needs to be set to be the address of hopital.ecl in your environment.
		String eclFile = "E:/Monitoring/bpMOP/input/hospital.ecl" ;
		
		// and the log file to be analyzed by the bpCMon. Note that, in the running, 
		// this logfile needs to be set to be the address of Hospital_log.xes in your environment.
		String logName ="E:/Monitoring/testData/loanApplicationLogs/Hospital_log/Hospital_log.xes"  ;
		
		// parse the ECLFile
		action.doParse(eclFile) ;
		
		//  generate bpCMon monitor 
		action.generateMoniotor();
		
		//  execute monitor to run the log file
		action.runMonitor(logName) ;
		
		// the follows are just printing the results for simplicity, based on compliance results.
		System.out.println("=============== the compliant result =========================") ;
		
		// if the compliance rules specified in ECL are compliant with logs, the return of the method, 
		//  i.e., getCompliantResult(), is an integer 1, o.w., 0 ;
		if ( action.getCompliantResult() == 1) {
			System.out.println("the log is compliant !") ;
		} else {
			
			// note that, if the result is not compliant, the method, getFailures(), would return all the failures.
			System.out.println("the log is not compliant and with " + action.getFailures().size()+" falures !"  ) ;
		}
		System.out.println("=============== the end =======================") ;

	}

}
